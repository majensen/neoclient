package tool::M4;
use strict;
use warnings;
use base qw( Alien::Base );

our $VERSION = '0.001';

1;
